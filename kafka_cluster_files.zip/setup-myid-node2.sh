#!/bin/bash
# This script sets up the myid file for Zookeeper on node2

mkdir -p /tmp/zookeeper/data
echo 2 > /tmp/zookeeper/data/myid

echo "myid file created with ID 2 at /tmp/zookeeper/data/myid"
