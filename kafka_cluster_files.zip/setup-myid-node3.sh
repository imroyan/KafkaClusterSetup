#!/bin/bash
# This script sets up the myid file for Zookeeper on node3

mkdir -p /tmp/zookeeper/data
echo 3 > /tmp/zookeeper/data/myid

echo "myid file created with ID 3 at /tmp/zookeeper/data/myid"
