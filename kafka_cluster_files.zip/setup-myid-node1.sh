#!/bin/bash
# This script sets up the myid file for Zookeeper on node1

mkdir -p /tmp/zookeeper/data
echo 1 > /tmp/zookeeper/data/myid

echo "myid file created with ID 1 at /tmp/zookeeper/data/myid"
